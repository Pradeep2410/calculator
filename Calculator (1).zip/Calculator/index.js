var val;
document.querySelector(".equal").addEventListener("click",function inputtext(){
    var input = document.querySelector(".input").value;
    console.log(input);
    var ans = eval(input);
    document.querySelector(".input").value = ans;

});
document.querySelector(".input").addEventListener("click",function (){
    document.querySelector(".input").value = null;

});
document.querySelector(".clear").addEventListener("click",function (){
    // val /= 10;
    // Math.abs(val);
    document.querySelector(".input").value = null;

});
for(var i=1;i<17;i++){
    document.querySelectorAll(".c")[i].addEventListener("click",function number(){
        
        document.querySelector(".input").innerHTML = "";
        var btn = this.innerHTML;
        console.log(btn);
        
        val = document.querySelector(".input").value += btn;
        console.log(val);
    });
}
